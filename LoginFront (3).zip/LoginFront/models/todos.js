const mongoose = require('mongoose')
let Schema = mongoose.Schema;

const TicketSchema = new Schema({

    title:{
        type:String,
        default:"Error loading ticket"
    },
    completed: {
        type: Boolean,
        default: false
    }


})

let Post = mongoose.model("todos", TicketSchema);
module.exports = Post;