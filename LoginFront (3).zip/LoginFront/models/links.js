const mongoose = require('mongoose')
let Schema = mongoose.Schema;

const LinksSchema = new Schema({

    _id:{
        type:String,
        default:"No Keywords Found"
    },
    link: {
        type: String,
        default: "Source not Found"
    }
})

module.exports = mongoose.model("links", LinksSchema)