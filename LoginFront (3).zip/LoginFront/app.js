const path = require('path')
const express = require('express')
const mongoose = require('mongoose')
const dotenv = require('dotenv')
const morgan = require('morgan')
const exphbs = require('express-handlebars')
const methodOverride = require('method-override')
const passport = require('passport')
const hbs = require('hbs')
const session = require('express-session')
const MongoStore = require('connect-mongo');
const connectDB = require('./config/db')
const { urlencoded } = require('express')
const { linkSync } = require('fs')



//load config
dotenv.config({path: './config/config.env'})

//passport config
require('./config/passport')(passport)
connectDB()

const app = express()

//body parser
app.use(urlencoded({ extended: false}))
app.use(express.json())

//logging
if(process.env.NODE_ENV== 'developement'){
    app.use(morgan('dev'))
}
// Handlebars
app.engine(
  '.hbs',  exphbs.engine({
    defaultLayout: 'main',
    extname: '.hbs',
  })
)
app.set('view engine', '.hbs')
app.use(express.static("images"));


//session
app.use(
    session({
      secret: 'iamsotired',
      resave: false,
      saveUninitialized: false
    })
  )

//passport middleware
app.use(passport.initialize())
app.use(passport.session())

//Static
app.use(express.static(path.join(__dirname, 'public')))

//routes
app.use('/', require('./routes/index'))
app.use('/login', require('./routes/login'))
app.use('/ticketForm', require('./routes/ticketForm'))
app.use('/loginBusiness', require('./routes/loginBusiness'))
app.use('/businessDashboard', require('./routes/businessDashboard'))
app.use('/auth', require('./routes/auth'))
app.use('/auth2', require('./routes/auth2'))
app.use('/direction', require  ('./routes/direction'))
app.use('/dashboard', require('./routes/dashboard'))
app.use('/faq', require('./routes/faq'))
app.use('/comments', require('./routes/comments'))
app.use('/images', require('./routes/images'))
app.use('/results', require('./routes/results'))
app.use('/resultsCars', require('./routes/resultsCars'))
app.use('/resultsTech', require('./routes/resultsTech'))
app.use('/resultsHome', require('./routes/resultsHome'))
app.use('/resultsFashion', require('./routes/resultsFashion'))
app.use('/resultsGroceries', require('./routes/resultsGroceries'))
app.use('/resultsPets', require('./routes/resultsPets'))
//app.use('/chatbotroute.open', require('./routes/chatbotroute'))
app.use(express.static('static'))
app.post('/postTicket/post', require('./routes/postTicket'))
var links = require('./models/links')
app.get('/search/:_id', async (req,res) => {
  var _id = req.params._id;
  //console.log(_id)
 
  let link = await links.findOne({_id: _id});
  if(link == null)
    res.send("");
  else
   res.send(link.link)
  //console.log( link.link);
  //res.send(link.link);
})
app.get('/searchQuery/:list', async (req,res) => {
  var _id = req.params.list;
  //console.log(_id)
  var keywords = _id.split(",");
  //console.log(keywords);
  var newLinks = new Array();
  for(var i = 0; i < keywords.length; i ++){
    console.log(keywords[i]);
    let link = await links.findOne({_id: keywords[i]});
    console.log(link);
    if( link !== null)
      newLinks.push(link.link);
    console.log(newLinks);
  }

  if(newLinks.length == 0)
    res.send("no results found");
 
    console.log('hit')
    res.send(newLinks)
  
   //console.log( link.link);
  //res.send(link.link);
})

const PORT = process.env.PORT || 6969
app.listen(
    PORT,
    console.log(`Server Running in ${process.env.NODE_ENV} mode on port ${PORT}`)
    )