const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')

//comments
Router.get('/',ensureAuth, (req, res)=> {
    res.render('comments',{
        layout: 'comments',
        name: req.user.firstName,
        isBus: req.user.isAdmin
    })
})

module.exports = Router