const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')


//loginBusiness
Router.get('/',ensureGuest, (req, res)=> {
    res.render('loginBusiness',{
        layout: 'loginBusiness',
    })
})
module.exports = Router