const formData = require('form-data')
const express = require('express')
const Router = express.Router()
const { ensureAuth } = require('../middleware/auth')
const mongoose = require('mongoose')
const todos = require('../models/todos')
const { stringify } = require('uuid')

//ticketform show add ticket
// @route     GET /tickets/add
Router.get('/add', ensureAuth, (req, res)=> {
    res.render('todos/add')
})

//ticketform show add ticket
// @route     POST /postTicket/post
Router.post('/postTicket/post', ensureAuth, async (req, res)=> {

    try{
        var body = req.body
        var str = ''
        for (var k in body) {
              str += k + ' ' + body[k] + ', ';
          }
        // console.log(body)
        // console.log(str)
        const newTodos = {
        title: str,
        completed: false,
        }
        await todos.create(newTodos)
        res.redirect('/dashboard')
    }catch(err){
        console.error(err)
    }

})

module.exports = Router