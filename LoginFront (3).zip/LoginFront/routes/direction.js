const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')

//direction
Router.get('/',ensureAuth, (req, res)=> {
    res.render('direction',{
        layout: 'direction',
        name: req.user.firstName,
        isBus: req.user.isAdmin
    })
})

module.exports = Router