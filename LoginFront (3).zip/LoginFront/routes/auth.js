const express = require('express')
const Router = express.Router()
const passport = require('passport')
const { ensureAuth,ensureGuest } = require('../middleware/auth')
const User = require('../models/User')
const window = require('window')




// @desc auth with google
// @route GET /auth/google
Router.get('/google', passport.authenticate('google', { scope: ['profile']} ))


//@desc google auth callback
// @route GET /auth/google/callback
Router.get('/google/callback', passport.authenticate('google', {
failureRedirect: '/'}), (req,res) =>{ 
    res.redirect('/direction')
})

//@desc logout user
//@route Get /auth/logout
Router.get('/logout', (req,res) => {
    req.logout()
    res.redirect('/')
})

module.exports = Router