const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')


//results
Router.get('/',ensureAuth, (req, res)=> {
    res.render('resultsTech',{
        layout: 'resultsTech',
    })
})

module.exports = Router