const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')

//direction
Router.get('/', (req, res)=> {
    res.render('faq',{
        layout: 'faq'
    })
})

module.exports = Router