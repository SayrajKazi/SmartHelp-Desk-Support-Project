const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')

//index/landing
Router.get('/', ensureGuest, (req, res)=> {
    res.render('index',{
        layout: 'index',
    })
})

module.exports = Router