const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')


//login
Router.get('/',ensureGuest, (req, res)=> {
    res.render('login',{
        layout: 'login',
    })
})

module.exports = Router