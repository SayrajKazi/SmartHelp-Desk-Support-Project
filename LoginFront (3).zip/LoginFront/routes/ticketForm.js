const express = require('express')
const Router = express.Router()
const { ensureAuth } = require('../middleware/auth')
const mongoose = require('mongoose')
const todos = require('../models/todos')

//ticketform
Router.get('/', ensureAuth, (req, res)=> {
    res.render('ticketForm',{
        layout: 'ticketForm',
    })
})
//post

module.exports = Router