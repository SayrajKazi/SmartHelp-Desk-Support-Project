const express = require('express')
const router = express.Router()
const { ensureAuth} = require('../middleware/auth')
const links = require('../models/links')
const toArray = require('./toArray')

// @desc    Show single link
// @route   GET /getLinks/get
