const express = require('express')
const Router = express.Router()
const passport = require('passport')
const { ensureAuth,ensureGuest } = require('../middleware/auth')


// @desc auth with google
// @route GET /auth2/google
Router.get('/google', passport.authenticate('google', { scope: ['profile']} ))


//@desc google auth callback
// @route GET /auth2/google/callback
Router.get('/google/callback', passport.authenticate('google', {
failureRedirect: '/'}), (req,res) =>{ res.redirect('/direction')})


module.exports = Router