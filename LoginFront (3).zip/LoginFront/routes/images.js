const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')

//direction
Router.get('/', (req, res)=> {
    res.render('/cars',{ Image: 'cars.png'
    })
})
Router.get('/', (req, res)=> {
    res.render('Home',{ Image: 'Home.png'
    })
})
Router.get('/', (req, res)=> {
    res.render('/pets',{
    })
})
Router.get('/', (req, res)=> {
    res.render('/technology',{
    })
})
Router.get('/', (req, res)=> {
    res.render('/groceries',{
    })
})
Router.get('/', (req, res)=> {
    res.render('/fashion',{
    })
})
module.exports = Router