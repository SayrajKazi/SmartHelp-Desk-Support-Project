const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')
const openForm = require('./chatbot.js')



// @route GET /chatbotroute/open
Router.get('/google', openForm )


