const express = require('express')
const Router = express.Router()
const { ensureAuth,ensureGuest } = require('../middleware/auth')


//index/landing
Router.get('/',ensureAuth, (req, res)=> {
    res.render('dashboard',{
        layout: 'dashboard', name: req.user.firstName
    })
})

module.exports = Router